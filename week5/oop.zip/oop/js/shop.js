class Shop {
    constructor(name, adress) {
        this.name = name;
        this.adress = adress;
        this.openinngHour = 8;
    }
    name = "balbla";
    
}

let littlePrince = new Shop ("Little Prince", "King George st. 19");