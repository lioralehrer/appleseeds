class Car {
    constructor(color, brand){
    this.color = color;
    this.brand = brand;
    }
    }
    let swift = new Car("green", "Suzuki");
    let civic = new Car("black", "Honda");
    let mycar = new Car ("white", "kia");
    let yourcar = new Car ("blue", "toyota");
    let shevi = new Car ("gold", "shevrolet");   