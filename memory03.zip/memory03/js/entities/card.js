class Card{
    constructor(){
        this.position = "back";
    }
}