

$("a").css({
    "font-family":"Courier New",
    "color": "green",
    "font-size": "100px",
    "display": "block"
});
$("a:nth-child(2)").attr("href","https://www.itc.tech");
$("a:nth-child(3)").css("color", "blue");
$("body").css("background-color", "orange");