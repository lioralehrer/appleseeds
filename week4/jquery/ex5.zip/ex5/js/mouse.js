$("div").mouseover( function(){
    $(this).addClass("some-container");
});

$("div").mouseup(function(){
    $(this).removeClass("some-container");
}); 
