document.getElementById("checkbox01").addEventListener("click", function(event){
    event.preventDefault(); document.getElementById("message").innerHTML="sorry this checkbox cannot be checked";
    
  });