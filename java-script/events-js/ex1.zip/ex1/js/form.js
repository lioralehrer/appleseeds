function sayHi(){
    var first = document.getElementById("first-name").value;
    var last = document.getElementById("last-name").value;
    console.log(`Hello  ${first}  ${last}`);
}